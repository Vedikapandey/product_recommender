import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Products table
export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  imageUrl: text("image_url").notNull(),
  features: text("features").array().notNull(),
});

// User interactions table - tracks views, clicks, purchases
export const userInteractions = pgTable("user_interactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(), // Simple user identifier (could be session-based)
  productId: varchar("product_id").notNull().references(() => products.id),
  interactionType: text("interaction_type").notNull(), // 'view', 'click', 'purchase'
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Recommendations table - stores generated recommendations
export const recommendations = pgTable("recommendations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(),
  productId: varchar("product_id").notNull().references(() => products.id),
  score: decimal("score", { precision: 5, scale: 2 }).notNull(), // Recommendation score
  explanation: text("explanation").notNull(), // AI-generated explanation
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Insert schemas
export const insertProductSchema = createInsertSchema(products).omit({ id: true });
export const insertUserInteractionSchema = createInsertSchema(userInteractions).omit({ id: true, timestamp: true });
export const insertRecommendationSchema = createInsertSchema(recommendations).omit({ id: true, timestamp: true });

// Types
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type UserInteraction = typeof userInteractions.$inferSelect;
export type InsertUserInteraction = z.infer<typeof insertUserInteractionSchema>;

export type Recommendation = typeof recommendations.$inferSelect;
export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;

// Extended type for recommendations with product details
export type RecommendationWithProduct = Recommendation & {
  product: Product;
};
