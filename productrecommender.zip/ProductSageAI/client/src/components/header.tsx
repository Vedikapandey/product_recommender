import { ShoppingBag, Sparkles } from "lucide-react";
import { Link, useLocation } from "wouter";
import { ThemeToggle } from "./theme-toggle";
import { Button } from "@/components/ui/button";

export function Header() {
  const [location] = useLocation();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link href="/">
          <div className="flex items-center gap-2 hover-elevate active-elevate-2 rounded-lg px-3 py-2 -ml-3 cursor-pointer" data-testid="link-home">
            <ShoppingBag className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">SmartShop</span>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          <Link href="/">
            <a
              className={`text-sm font-medium transition-colors hover:text-primary ${
                location === "/" ? "text-foreground" : "text-muted-foreground"
              }`}
              data-testid="link-shop"
            >
              Shop
            </a>
          </Link>
          <Link href="/recommendations">
            <a
              className={`text-sm font-medium transition-colors hover:text-primary flex items-center gap-1.5 ${
                location === "/recommendations" ? "text-foreground" : "text-muted-foreground"
              }`}
              data-testid="link-recommendations"
            >
              <Sparkles className="h-4 w-4" />
              For You
            </a>
          </Link>
          <Link href="/dashboard">
            <a
              className={`text-sm font-medium transition-colors hover:text-primary ${
                location === "/dashboard" ? "text-foreground" : "text-muted-foreground"
              }`}
              data-testid="link-dashboard"
            >
              Dashboard
            </a>
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
