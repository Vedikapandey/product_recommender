import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, ShoppingCart, TrendingUp } from "lucide-react";
import type { RecommendationWithProduct } from "@shared/schema";

interface RecommendationCardProps {
  recommendation: RecommendationWithProduct;
  onAddToCart?: (productId: string) => void;
}

export function RecommendationCard({ recommendation, onAddToCart }: RecommendationCardProps) {
  const { product, explanation, score } = recommendation;
  
  const handleAddToCart = () => {
    if (onAddToCart) onAddToCart(product.id);
  };

  return (
    <Card 
      className="overflow-hidden hover-elevate transition-all duration-200 border-2 border-primary/20"
      data-testid={`card-recommendation-${recommendation.id}`}
    >
      <CardContent className="p-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Product Image */}
          <div className="relative w-full lg:w-48 h-48 flex-shrink-0 rounded-lg overflow-hidden bg-muted">
            <img
              src={product.imageUrl}
              alt={product.name}
              className="h-full w-full object-cover"
              loading="lazy"
            />
          </div>

          {/* Product Details & AI Explanation */}
          <div className="flex-1 space-y-4">
            <div className="space-y-2">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div className="space-y-1">
                  <h3 className="text-xl font-semibold" data-testid={`text-rec-product-name-${recommendation.id}`}>
                    {product.name}
                  </h3>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">
                      {product.category}
                    </Badge>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <TrendingUp className="h-3.5 w-3.5" />
                      <span>{score}% match</span>
                    </div>
                  </div>
                </div>
                <div className="text-2xl font-bold text-primary" data-testid={`text-rec-price-${recommendation.id}`}>
                  ${product.price}
                </div>
              </div>

              <p className="text-sm text-muted-foreground">
                {product.description}
              </p>
            </div>

            {/* AI Explanation */}
            <div className="bg-accent/30 rounded-lg p-4 space-y-2 border border-accent-border">
              <div className="flex items-center gap-2 text-accent-foreground">
                <Sparkles className="h-4 w-4" />
                <span className="text-sm font-medium">Why this product?</span>
              </div>
              <p className="text-sm italic leading-relaxed" data-testid={`text-ai-explanation-${recommendation.id}`}>
                {explanation}
              </p>
            </div>

            {/* Features */}
            {product.features && product.features.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {product.features.slice(0, 3).map((feature, idx) => (
                  <Badge key={idx} variant="outline" className="text-xs">
                    {feature}
                  </Badge>
                ))}
              </div>
            )}

            <Button 
              onClick={handleAddToCart}
              className="gap-2 w-full sm:w-auto"
              data-testid={`button-add-cart-rec-${recommendation.id}`}
            >
              <ShoppingCart className="h-4 w-4" />
              Add to Cart
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
