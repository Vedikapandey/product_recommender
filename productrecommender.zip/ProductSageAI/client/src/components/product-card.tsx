import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, ShoppingCart } from "lucide-react";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
  onView?: (productId: string) => void;
  onAddToCart?: (productId: string) => void;
}

export function ProductCard({ product, onView, onAddToCart }: ProductCardProps) {
  const handleView = () => {
    if (onView) onView(product.id);
  };

  const handleAddToCart = () => {
    if (onAddToCart) onAddToCart(product.id);
  };

  return (
    <Card 
      className="overflow-hidden hover-elevate transition-all duration-200 group"
      data-testid={`card-product-${product.id}`}
    >
      <CardHeader className="p-0">
        <div className="relative aspect-[4/3] overflow-hidden bg-muted">
          <img
            src={product.imageUrl}
            alt={product.name}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
          />
          <Button
            size="icon"
            variant="secondary"
            className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={handleView}
            data-testid={`button-view-${product.id}`}
          >
            <Eye className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="p-4 space-y-2">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold text-lg line-clamp-2" data-testid={`text-product-name-${product.id}`}>
            {product.name}
          </h3>
        </div>
        
        <Badge variant="secondary" className="text-xs" data-testid={`badge-category-${product.id}`}>
          {product.category}
        </Badge>
        
        <p className="text-sm text-muted-foreground line-clamp-2">
          {product.description}
        </p>
      </CardContent>

      <CardFooter className="p-4 pt-0 flex items-center justify-between gap-4">
        <div className="text-2xl font-bold text-primary" data-testid={`text-price-${product.id}`}>
          ${product.price}
        </div>
        <Button 
          onClick={handleAddToCart}
          className="gap-2"
          data-testid={`button-add-cart-${product.id}`}
        >
          <ShoppingCart className="h-4 w-4" />
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
}
