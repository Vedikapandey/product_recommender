import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/header";
import { StatsCard } from "@/components/stats-card";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Eye, ShoppingCart, Sparkles, Package, Loader2, TrendingUp } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import type { Product, UserInteraction } from "@shared/schema";

interface DashboardStats {
  totalViews: number;
  totalPurchases: number;
  totalRecommendations: number;
  totalProducts: number;
  categoryBreakdown: Array<{ category: string; count: number }>;
  recentInteractions: Array<UserInteraction & { product?: Product }>;
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-12">
        <div className="space-y-8">
          {/* Header */}
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h1>
            <p className="text-muted-foreground">
              Track user behavior and recommendation performance
            </p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-24">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : stats ? (
            <>
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatsCard
                  title="Total Views"
                  value={stats.totalViews}
                  icon={Eye}
                  description="Product page views"
                />
                <StatsCard
                  title="Total Purchases"
                  value={stats.totalPurchases}
                  icon={ShoppingCart}
                  description="Items added to cart"
                />
                <StatsCard
                  title="AI Recommendations"
                  value={stats.totalRecommendations}
                  icon={Sparkles}
                  description="Generated suggestions"
                />
                <StatsCard
                  title="Products"
                  value={stats.totalProducts}
                  icon={Package}
                  description="In catalog"
                />
              </div>

              {/* Category Breakdown Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Category Performance
                  </CardTitle>
                  <CardDescription>Product interactions by category</CardDescription>
                </CardHeader>
                <CardContent>
                  {stats.categoryBreakdown && stats.categoryBreakdown.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={stats.categoryBreakdown}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                        <XAxis 
                          dataKey="category" 
                          className="text-xs fill-muted-foreground"
                        />
                        <YAxis className="text-xs fill-muted-foreground" />
                        <Tooltip 
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '0.5rem',
                          }}
                        />
                        <Bar 
                          dataKey="count" 
                          fill="hsl(var(--primary))" 
                          radius={[8, 8, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex items-center justify-center py-12 text-muted-foreground">
                      No category data available
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Recent Interactions */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest user interactions with products</CardDescription>
                </CardHeader>
                <CardContent>
                  {stats.recentInteractions && stats.recentInteractions.length > 0 ? (
                    <div className="space-y-4">
                      {stats.recentInteractions.map((interaction, idx) => (
                        <div
                          key={interaction.id}
                          className="flex items-center justify-between p-4 rounded-lg bg-muted/50 hover-elevate"
                          data-testid={`interaction-${idx}`}
                        >
                          <div className="flex items-center gap-4 flex-1">
                            <div className="h-12 w-12 rounded-lg bg-background flex items-center justify-center">
                              {interaction.interactionType === 'view' ? (
                                <Eye className="h-5 w-5 text-primary" />
                              ) : interaction.interactionType === 'purchase' ? (
                                <ShoppingCart className="h-5 w-5 text-green-600" />
                              ) : (
                                <Sparkles className="h-5 w-5 text-accent-foreground" />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium truncate">
                                {interaction.product?.name || 'Unknown Product'}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {new Date(interaction.timestamp).toLocaleString()}
                              </p>
                            </div>
                          </div>
                          <Badge variant={
                            interaction.interactionType === 'purchase' ? 'default' : 'secondary'
                          }>
                            {interaction.interactionType}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center py-12 text-muted-foreground">
                      No recent activity
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
}
