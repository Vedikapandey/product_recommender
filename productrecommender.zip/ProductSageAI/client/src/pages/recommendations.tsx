import { useQuery, useMutation } from "@tanstack/react-query";
import { RecommendationCard } from "@/components/recommendation-card";
import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Sparkles, Loader2, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { RecommendationWithProduct } from "@shared/schema";

export default function Recommendations() {
  const { toast } = useToast();

  const { data: recommendations, isLoading, refetch } = useQuery<RecommendationWithProduct[]>({
    queryKey: ['/api/recommendations'],
  });

  const generateRecommendations = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/recommendations/generate', {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recommendations'] });
      toast({
        title: "Recommendations updated",
        description: "Your personalized recommendations have been refreshed.",
      });
    },
  });

  const trackInteraction = useMutation({
    mutationFn: async (data: { productId: string; interactionType: string }) => {
      return apiRequest('POST', '/api/interactions', data);
    },
  });

  const handleAddToCart = (productId: string) => {
    trackInteraction.mutate({ productId, interactionType: 'purchase' });
    toast({
      title: "Added to cart",
      description: "Product has been added to your cart.",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-accent/10 border-b">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-4">
              <Sparkles className="h-4 w-4" />
              <span className="text-sm font-medium">AI-Powered Recommendations</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
              Curated Just For You
            </h1>
            <p className="text-lg text-muted-foreground">
              Discover products that match your preferences with intelligent recommendations
            </p>
            <Button 
              onClick={() => generateRecommendations.mutate()}
              disabled={generateRecommendations.isPending}
              className="gap-2"
              data-testid="button-refresh-recommendations"
            >
              {generateRecommendations.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4" />
                  Refresh Recommendations
                </>
              )}
            </Button>
          </div>
        </div>
      </section>

      {/* Recommendations */}
      <section className="container mx-auto px-4 py-12">
        {isLoading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : recommendations && recommendations.length > 0 ? (
          <div className="max-w-5xl mx-auto space-y-6">
            {recommendations.map(recommendation => (
              <RecommendationCard
                key={recommendation.id}
                recommendation={recommendation}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <Sparkles className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No recommendations yet</h3>
            <p className="text-muted-foreground mb-6">
              Start browsing products to get personalized recommendations
            </p>
            <Button onClick={() => generateRecommendations.mutate()} data-testid="button-generate-recommendations">
              Generate Recommendations
            </Button>
          </div>
        )}
      </section>
    </div>
  );
}
