# E-Commerce Product Recommender - Design Guidelines

## Design Approach: Reference-Based (Modern E-Commerce)

**Primary References**: Shopify's clean product grids, Etsy's personalized discovery experience, Amazon's recommendation patterns
**Justification**: E-commerce is experience-focused, visually-rich, and design-differentiated. The AI-powered recommendation aspect requires trust-building through modern, polished design.

## Core Design Elements

### A. Color Palette

**Light Mode**:
- Primary: 230 70% 45% (Deep blue - trust and reliability)
- Secondary: 230 15% 25% (Charcoal - text and headers)
- Accent: 340 85% 55% (Coral red - CTAs and highlights)
- Background: 0 0% 98% (Off-white)
- Surface: 0 0% 100% (Pure white cards)
- Success: 145 65% 45% (Purchase confirmations)

**Dark Mode**:
- Primary: 230 75% 60% (Lighter blue)
- Secondary: 230 10% 90% (Light gray text)
- Accent: 340 80% 60% (Lighter coral)
- Background: 230 15% 10% (Deep charcoal)
- Surface: 230 12% 15% (Elevated cards)

### B. Typography

**Font Families**:
- Headings: Inter (700, 600, 500) - clean, modern
- Body: Inter (400, 500) - optimal readability
- Accents: Inter (600) - AI explanations

**Scale**:
- Hero/Page Titles: text-4xl to text-6xl
- Section Headers: text-2xl to text-3xl
- Product Names: text-lg to text-xl font-semibold
- Body/Descriptions: text-base
- AI Explanations: text-sm font-medium (slightly emphasized)
- Metadata: text-xs to text-sm text-gray-500

### C. Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 24
- Micro spacing: p-2, gap-2 (tight elements)
- Standard spacing: p-4, gap-4, m-6 (cards, sections)
- Section padding: py-12 to py-24
- Container: max-w-7xl mx-auto px-4

**Grid System**:
- Product grids: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4
- Recommendation cards: grid-cols-1 lg:grid-cols-2 gap-6
- Dashboard metrics: grid-cols-2 md:grid-cols-4 gap-4

### D. Component Library

**Navigation**:
- Sticky header with logo, search bar, and user menu
- Transparent-to-solid on scroll transition
- Shopping cart icon with item count badge

**Product Cards**:
- Image-first design with 4:3 aspect ratio
- Hover effect: subtle scale and shadow increase
- Price prominent below product name
- Quick view button overlay on hover
- Rounded corners: rounded-lg

**AI Recommendation Cards** (Signature Component):
- Two-column layout: product image left, details right
- AI explanation in italic text with subtle gradient background
- "Why this?" badge icon (sparkle/brain icon from Heroicons)
- Confidence indicator: subtle progress bar or star rating
- Bordered with accent color: border-l-4 border-accent

**Dashboard Components**:
- Stat cards with large numbers and trend indicators
- Clean data tables with alternating row colors
- Simple line charts for behavior tracking
- Filter dropdowns and date pickers

**Forms & Inputs**:
- Rounded inputs: rounded-md with focus ring
- Search bar with icon prefix
- Filter pills with clear X button
- Consistent dark mode support

**Buttons**:
- Primary: Solid accent color, rounded-lg, px-6 py-3
- Secondary: Outline with hover fill
- Ghost: Text only with hover background
- Disabled state: reduced opacity

### E. Animations

Use sparingly for polish:
- Product card hover: transform scale-105 transition-transform duration-200
- Page transitions: fade-in for content loading
- AI explanation reveal: slide-down with fade
- Shopping cart add: brief pulse animation
- No auto-playing carousels or distracting effects

## Images

**Hero Section**:
- Large hero image showcasing curated products in lifestyle context
- Dimensions: Full-width, 60vh on desktop, 40vh on mobile
- Overlay: Subtle gradient overlay (bottom-to-top) for text readability
- Content: Centered headline "Discover Products You'll Love" + subheading about AI-powered recommendations
- CTA buttons with backdrop-blur-md background

**Product Images**:
- High-quality product photography on white/neutral backgrounds
- Consistent aspect ratios across catalog
- Hover state: show alternate angle if available

**Additional Images**:
- Dashboard: Small thumbnail previews in recommendation tables
- Empty states: Friendly illustrations when no recommendations exist
- Trust indicators: Small brand/security badges in footer

## Page-Specific Layouts

**Shopping Interface**:
- Hero section with personalized greeting
- "Recommended for You" section (2-column AI cards)
- Product grid below recommendations
- Sticky filter sidebar on desktop

**Dashboard**:
- Top metrics row (4 stat cards)
- Recent recommendations table
- User behavior chart
- Product performance grid

**Product Detail**:
- Large product gallery (left column)
- Details and AI explanation (right column)
- "Similar Products" carousel at bottom

## Key Design Principles

1. **Trust Through Transparency**: AI explanations visible but not intrusive
2. **Scannable Hierarchy**: Large product images, clear pricing, readable AI text
3. **Conversion-Focused**: Strategic use of accent color for CTAs
4. **Data Clarity**: Dashboard balances visual appeal with information density
5. **Responsive First**: Mobile-optimized product cards and touch-friendly interactions