# SmartShop - AI-Powered Product Recommendations

## Overview

SmartShop is an e-commerce platform with AI-powered product recommendations. The application tracks user interactions (views, clicks, purchases) and uses this behavioral data to generate personalized product recommendations. The system employs collaborative filtering and content-based filtering algorithms, with AI-generated explanations for each recommendation using OpenAI's GPT-5 model.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18 with TypeScript
- Vite as the build tool and dev server
- Wouter for client-side routing
- TanStack Query (React Query) for server state management
- Tailwind CSS for styling with shadcn/ui component library

**Design System:**
- Uses shadcn/ui's "new-york" style variant
- Custom theme with light/dark mode support
- Color palette based on e-commerce best practices (deep blue for trust, coral for CTAs)
- Inter font family for both headings and body text
- Responsive grid layouts with Tailwind's utility classes

**Key Pages:**
1. **Shop** (`/`) - Product browsing with search and category filtering
2. **Recommendations** (`/recommendations`) - AI-powered personalized product suggestions
3. **Dashboard** (`/dashboard`) - Analytics and user behavior insights
4. **404 Page** - Not found error handling

**Component Architecture:**
- Reusable UI components in `client/src/components/ui/` (shadcn/ui)
- Feature components: ProductCard, RecommendationCard, StatsCard
- Shared Header with navigation and theme toggle
- Toast notifications for user feedback

### Backend Architecture

**Technology Stack:**
- Express.js for HTTP server
- TypeScript for type safety
- In-memory storage (MemStorage class) as default data layer
- Drizzle ORM configured for PostgreSQL (schema defined, ready for database integration)

**API Endpoints:**
- `GET /api/products` - Fetch all products
- `GET /api/products/:id` - Fetch single product
- `POST /api/interactions` - Track user interactions (view, click, purchase)
- `GET /api/recommendations` - Get personalized recommendations for user
- `POST /api/recommendations/generate` - Generate new AI recommendations
- `GET /api/dashboard/stats` - Get analytics dashboard data

**Recommendation Engine:**
- Hybrid approach combining collaborative filtering and content-based filtering
- Calculates product scores based on user interaction history
- Supports category matching, feature similarity, and popularity metrics
- Generates explanations using AI for why products are recommended

**Storage Layer:**
- Abstract `IStorage` interface for data operations
- Default `MemStorage` implementation with in-memory Maps
- Seed data included for demo purposes (sample products)
- Ready for PostgreSQL integration via Drizzle ORM

### Data Models

**Products:**
- id, name, description, category, price, imageUrl, features[]

**User Interactions:**
- id, userId, productId, interactionType (view/click/purchase), timestamp

**Recommendations:**
- id, userId, productId, score, explanation (AI-generated), timestamp

**Type Safety:**
- Zod schemas for validation (drizzle-zod integration)
- TypeScript types inferred from Drizzle schema
- Shared types between client and server via `@shared/schema`

### Session & User Management

**Current Implementation:**
- Simple user ID approach with default demo user (`demo-user`)
- No authentication system implemented
- Session-based tracking via user interactions

**Future Consideration:**
- System is designed to easily integrate proper authentication
- User context can be extended for multi-user support

## External Dependencies

### Third-Party Services

**OpenAI Integration:**
- Uses GPT-5 model for generating recommendation explanations
- Requires `OPENAI_API_KEY` environment variable
- Structured JSON output for consistent response format
- Fallback to generic explanation on API errors

**Database:**
- Drizzle ORM configured for PostgreSQL via `@neondatabase/serverless`
- Requires `DATABASE_URL` environment variable
- Schema defined in `shared/schema.ts`
- Migrations directory configured in `drizzle.config.ts`
- Currently using in-memory storage (can be swapped to Postgres)

### UI Component Library

**shadcn/ui:**
- Radix UI primitives for accessible components
- Custom Tailwind configuration for theming
- Component variants using class-variance-authority
- Path aliases configured for easy imports (@/components, @/lib, etc.)

### Development Tools

**Replit-Specific:**
- `@replit/vite-plugin-runtime-error-modal` for error overlay
- `@replit/vite-plugin-cartographer` for development mapping (dev only)
- `@replit/vite-plugin-dev-banner` for development banner (dev only)

**Build & Development:**
- esbuild for server bundling
- Vite for client bundling and HMR
- tsx for TypeScript execution in development
- PostCSS with Tailwind and Autoprefixer

### Data Visualization

**Recharts:**
- Used in Dashboard for category breakdown charts
- Bar charts showing interaction patterns
- Responsive container for adaptive sizing