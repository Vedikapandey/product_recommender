import { storage } from "./storage";
import type { Product, UserInteraction } from "@shared/schema";

interface ProductScore {
  product: Product;
  score: number;
  reason: string;
}

export class RecommendationEngine {
  /**
   * Generate product recommendations based on user behavior
   * Uses collaborative filtering and content-based filtering
   */
  async generateRecommendations(userId: string, limit: number = 5): Promise<ProductScore[]> {
    const userInteractions = await storage.getInteractionsByUserId(userId);
    const allProducts = await storage.getAllProducts();
    
    if (userInteractions.length === 0) {
      // No interaction history - recommend popular or diverse products
      return this.getPopularProducts(allProducts, limit);
    }

    // Get user's interaction patterns
    const interactedProductIds = new Set(userInteractions.map(i => i.productId));
    const viewedProducts = await this.getProductsByIds(Array.from(interactedProductIds));
    
    // Calculate scores for products user hasn't interacted with
    const scores: ProductScore[] = [];
    
    for (const product of allProducts) {
      if (interactedProductIds.has(product.id)) {
        continue; // Skip products user already interacted with
      }
      
      const score = await this.calculateProductScore(product, viewedProducts, userInteractions);
      if (score > 0) {
        scores.push({
          product,
          score,
          reason: this.generateScoreReason(product, viewedProducts)
        });
      }
    }
    
    // Sort by score and return top recommendations
    return scores
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  /**
   * Calculate recommendation score for a product
   */
  private async calculateProductScore(
    product: Product,
    userProducts: Product[],
    userInteractions: UserInteraction[]
  ): Promise<number> {
    let score = 0;
    
    // Category-based scoring (collaborative filtering approach)
    const userCategories = userProducts.map(p => p.category);
    const categoryMatches = userCategories.filter(c => c === product.category).length;
    score += categoryMatches * 30;
    
    // Feature overlap scoring (content-based filtering)
    const userFeatures = new Set(userProducts.flatMap(p => p.features));
    const productFeaturesArray = product.features;
    const featureOverlap = productFeaturesArray.filter(f => userFeatures.has(f)).length;
    score += featureOverlap * 20;
    
    // Price range similarity
    const avgUserPrice = userProducts.reduce((sum, p) => sum + parseFloat(p.price), 0) / userProducts.length;
    const priceDiff = Math.abs(parseFloat(product.price) - avgUserPrice);
    const priceScore = Math.max(0, 100 - priceDiff / 10);
    score += priceScore * 0.5;
    
    // Boost score based on interaction types
    const purchaseWeight = userInteractions.filter(i => i.interactionType === 'purchase').length * 10;
    score += purchaseWeight * 0.3;
    
    return Math.min(100, Math.round(score));
  }

  /**
   * Get popular products when no user history exists
   */
  private async getPopularProducts(products: Product[], limit: number): Promise<ProductScore[]> {
    const allInteractions = await storage.getAllInteractions();
    
    // Count interactions per product
    const productInteractionCount = new Map<string, number>();
    allInteractions.forEach(interaction => {
      const count = productInteractionCount.get(interaction.productId) || 0;
      productInteractionCount.set(interaction.productId, count + 1);
    });
    
    // Score products by popularity
    const scored = products.map(product => {
      const interactionCount = productInteractionCount.get(product.id) || 0;
      return {
        product,
        score: Math.min(100, interactionCount * 10 + 50), // Base score of 50
        reason: "Popular among other shoppers"
      };
    });
    
    return scored
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  /**
   * Generate human-readable reason for recommendation
   */
  private generateScoreReason(product: Product, userProducts: Product[]): string {
    const userCategories = userProducts.map(p => p.category);
    const categoryMatch = userCategories.includes(product.category);
    
    if (categoryMatch) {
      return `Based on your interest in ${product.category}`;
    }
    
    return "Recommended based on your browsing patterns";
  }

  /**
   * Helper to get products by IDs
   */
  private async getProductsByIds(ids: string[]): Promise<Product[]> {
    const products: Product[] = [];
    for (const id of ids) {
      const product = await storage.getProduct(id);
      if (product) products.push(product);
    }
    return products;
  }

  /**
   * Generate user behavior summary for AI explanations
   */
  async generateUserBehaviorSummary(userId: string): Promise<string> {
    const interactions = await storage.getInteractionsByUserId(userId);
    
    if (interactions.length === 0) {
      return "New user exploring our catalog";
    }

    const productIds = interactions.map(i => i.productId);
    const products = await this.getProductsByIds(productIds);
    
    const categorySet = new Set(products.map(p => p.category));
    const categories = Array.from(categorySet);
    const viewCount = interactions.filter(i => i.interactionType === 'view').length;
    const purchaseCount = interactions.filter(i => i.interactionType === 'purchase').length;
    
    return `User has viewed ${viewCount} products and purchased ${purchaseCount} items. Interested in: ${categories.join(', ')}`;
  }
}

export const recommendationEngine = new RecommendationEngine();
