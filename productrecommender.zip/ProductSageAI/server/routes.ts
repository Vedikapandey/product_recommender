import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { recommendationEngine } from "./recommendation-engine";
import { generateRecommendationExplanation } from "./openai";
import { insertUserInteractionSchema } from "@shared/schema";
import type { RecommendationWithProduct } from "@shared/schema";

// Simple user ID management (in production, use proper auth)
const DEFAULT_USER_ID = "demo-user";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all products
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  // Get single product
  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Track user interaction
  app.post("/api/interactions", async (req, res) => {
    try {
      const validatedData = insertUserInteractionSchema.parse({
        userId: DEFAULT_USER_ID,
        productId: req.body.productId,
        interactionType: req.body.interactionType,
      });
      
      const interaction = await storage.createInteraction(validatedData);
      res.json(interaction);
    } catch (error) {
      res.status(400).json({ error: "Invalid interaction data" });
    }
  });

  // Get recommendations for user
  app.get("/api/recommendations", async (req, res) => {
    try {
      const recommendations = await storage.getRecommendationsByUserId(DEFAULT_USER_ID);
      
      // Enrich with product details
      const enriched: RecommendationWithProduct[] = [];
      for (const rec of recommendations) {
        const product = await storage.getProduct(rec.productId);
        if (product) {
          enriched.push({ ...rec, product });
        }
      }
      
      res.json(enriched);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recommendations" });
    }
  });

  // Generate new recommendations
  app.post("/api/recommendations/generate", async (req, res) => {
    try {
      // Delete old recommendations
      await storage.deleteRecommendationsByUserId(DEFAULT_USER_ID);
      
      // Generate new recommendations
      const productScores = await recommendationEngine.generateRecommendations(DEFAULT_USER_ID, 5);
      
      // Generate AI explanations and save recommendations
      const userBehavior = await recommendationEngine.generateUserBehaviorSummary(DEFAULT_USER_ID);
      
      const recommendations = [];
      for (const { product, score } of productScores) {
        const explanation = await generateRecommendationExplanation(
          product.name,
          product.category,
          product.description,
          userBehavior
        );
        
        const rec = await storage.createRecommendation({
          userId: DEFAULT_USER_ID,
          productId: product.id,
          score: score.toString(),
          explanation
        });
        
        recommendations.push(rec);
      }
      
      res.json(recommendations);
    } catch (error) {
      console.error("Error generating recommendations:", error);
      res.status(500).json({ error: "Failed to generate recommendations" });
    }
  });

  // Dashboard statistics
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const allInteractions = await storage.getAllInteractions();
      const allProducts = await storage.getAllProducts();
      const allRecommendations = await storage.getRecommendationsByUserId(DEFAULT_USER_ID);
      
      const totalViews = allInteractions.filter(i => i.interactionType === 'view').length;
      const totalPurchases = allInteractions.filter(i => i.interactionType === 'purchase').length;
      
      // Category breakdown
      const categoryCount = new Map<string, number>();
      for (const interaction of allInteractions) {
        const product = await storage.getProduct(interaction.productId);
        if (product) {
          categoryCount.set(product.category, (categoryCount.get(product.category) || 0) + 1);
        }
      }
      
      const categoryBreakdown = Array.from(categoryCount.entries()).map(([category, count]) => ({
        category,
        count
      }));
      
      // Recent interactions with product details
      const recentInteractions = allInteractions
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .slice(0, 10);
      
      const enrichedInteractions = [];
      for (const interaction of recentInteractions) {
        const product = await storage.getProduct(interaction.productId);
        enrichedInteractions.push({
          ...interaction,
          product
        });
      }
      
      res.json({
        totalViews,
        totalPurchases,
        totalRecommendations: allRecommendations.length,
        totalProducts: allProducts.length,
        categoryBreakdown,
        recentInteractions: enrichedInteractions
      });
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
