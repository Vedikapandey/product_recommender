import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function generateRecommendationExplanation(
  productName: string,
  productCategory: string,
  productDescription: string,
  userBehavior: string
): Promise<string> {
  try {
    const prompt = `You are an AI shopping assistant. Generate a personalized, compelling explanation for why a product is being recommended to a user based on their browsing behavior.

Product Details:
- Name: ${productName}
- Category: ${productCategory}
- Description: ${productDescription}

User Behavior:
${userBehavior}

Generate a friendly, persuasive explanation (2-3 sentences) that explains why this product matches the user's interests. Make it personal and engaging. Respond with JSON in this format: { "explanation": "your explanation here" }`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a helpful shopping assistant that creates personalized product recommendations. Be concise, friendly, and persuasive."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 200,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"explanation": "This product matches your interests based on your browsing history."}');
    return result.explanation;
  } catch (error) {
    console.error("Error generating AI explanation:", error);
    return "This product is recommended based on your browsing history and preferences.";
  }
}
