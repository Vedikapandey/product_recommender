import { 
  type Product, 
  type InsertProduct,
  type UserInteraction,
  type InsertUserInteraction,
  type Recommendation,
  type InsertRecommendation,
  type RecommendationWithProduct
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Products
  getAllProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // User Interactions
  getAllInteractions(): Promise<UserInteraction[]>;
  getInteractionsByUserId(userId: string): Promise<UserInteraction[]>;
  getInteractionsByProductId(productId: string): Promise<UserInteraction[]>;
  createInteraction(interaction: InsertUserInteraction): Promise<UserInteraction>;
  
  // Recommendations
  getRecommendationsByUserId(userId: string): Promise<Recommendation[]>;
  createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation>;
  deleteRecommendationsByUserId(userId: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private products: Map<string, Product>;
  private interactions: Map<string, UserInteraction>;
  private recommendations: Map<string, Recommendation>;

  constructor() {
    this.products = new Map();
    this.interactions = new Map();
    this.recommendations = new Map();
    
    // Seed with sample products
    this.seedProducts();
  }

  private seedProducts() {
    const sampleProducts: InsertProduct[] = [
      {
        name: "Wireless Noise-Cancelling Headphones",
        description: "Premium over-ear headphones with active noise cancellation, 30-hour battery life, and crystal-clear audio quality.",
        category: "Electronics",
        price: "299.99",
        imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80",
        features: ["Active Noise Cancellation", "30hr Battery", "Bluetooth 5.0", "Premium Sound"]
      },
      {
        name: "Smart Fitness Watch",
        description: "Track your health and fitness goals with heart rate monitoring, GPS, and sleep tracking capabilities.",
        category: "Electronics",
        price: "249.99",
        imageUrl: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&q=80",
        features: ["Heart Rate Monitor", "GPS Tracking", "Water Resistant", "Sleep Analysis"]
      },
      {
        name: "Ergonomic Office Chair",
        description: "Comfortable mesh office chair with lumbar support, adjustable armrests, and breathable design for all-day comfort.",
        category: "Furniture",
        price: "399.99",
        imageUrl: "https://images.unsplash.com/photo-1580480055273-228ff5388ef8?w=800&q=80",
        features: ["Lumbar Support", "Adjustable Height", "Breathable Mesh", "360° Swivel"]
      },
      {
        name: "Portable Bluetooth Speaker",
        description: "Compact waterproof speaker with 360-degree sound, 12-hour battery life, and powerful bass.",
        category: "Electronics",
        price: "79.99",
        imageUrl: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&q=80",
        features: ["Waterproof", "12hr Battery", "360° Sound", "Compact Design"]
      },
      {
        name: "Premium Yoga Mat",
        description: "Non-slip, eco-friendly yoga mat with extra cushioning for comfort during any workout or meditation session.",
        category: "Sports & Outdoors",
        price: "59.99",
        imageUrl: "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=800&q=80",
        features: ["Non-Slip Surface", "Eco-Friendly", "Extra Cushioning", "Easy to Clean"]
      },
      {
        name: "Stainless Steel Water Bottle",
        description: "Insulated water bottle that keeps drinks cold for 24 hours or hot for 12 hours. BPA-free and leak-proof.",
        category: "Sports & Outdoors",
        price: "34.99",
        imageUrl: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&q=80",
        features: ["24hr Cold", "12hr Hot", "BPA-Free", "Leak-Proof"]
      },
      {
        name: "Modern Standing Desk",
        description: "Electric height-adjustable standing desk with memory presets and spacious work surface for productivity.",
        category: "Furniture",
        price: "599.99",
        imageUrl: "https://images.unsplash.com/photo-1595515106969-1ce29566ff1c?w=800&q=80",
        features: ["Electric Adjustment", "Memory Presets", "Spacious Surface", "Cable Management"]
      },
      {
        name: "Smart LED Desk Lamp",
        description: "Adjustable LED desk lamp with wireless charging, touch controls, and multiple brightness settings.",
        category: "Home & Office",
        price: "89.99",
        imageUrl: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=800&q=80",
        features: ["Wireless Charging", "Touch Control", "Adjustable Brightness", "USB Port"]
      },
      {
        name: "Premium Coffee Maker",
        description: "Programmable coffee maker with thermal carafe, brew strength control, and auto shut-off feature.",
        category: "Home & Kitchen",
        price: "149.99",
        imageUrl: "https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=800&q=80",
        features: ["Programmable", "Thermal Carafe", "Brew Strength Control", "Auto Shut-off"]
      },
      {
        name: "Mechanical Gaming Keyboard",
        description: "RGB backlit mechanical keyboard with customizable keys, anti-ghosting, and durable switches.",
        category: "Electronics",
        price: "129.99",
        imageUrl: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&q=80",
        features: ["RGB Backlit", "Mechanical Switches", "Anti-Ghosting", "Customizable"]
      },
      {
        name: "Minimalist Backpack",
        description: "Sleek laptop backpack with padded compartments, water-resistant material, and ergonomic design.",
        category: "Bags & Accessories",
        price: "79.99",
        imageUrl: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&q=80",
        features: ["Laptop Compartment", "Water-Resistant", "Ergonomic", "Multiple Pockets"]
      },
      {
        name: "Air Purifier",
        description: "HEPA air purifier with 3-stage filtration, quiet operation, and smart air quality monitoring.",
        category: "Home & Office",
        price: "199.99",
        imageUrl: "https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=800&q=80",
        features: ["HEPA Filter", "3-Stage Filtration", "Quiet Operation", "Air Quality Monitor"]
      }
    ];

    sampleProducts.forEach(product => {
      const id = randomUUID();
      this.products.set(id, { ...product, id });
    });
  }

  // Products
  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { ...insertProduct, id };
    this.products.set(id, product);
    return product;
  }

  // User Interactions
  async getAllInteractions(): Promise<UserInteraction[]> {
    return Array.from(this.interactions.values());
  }

  async getInteractionsByUserId(userId: string): Promise<UserInteraction[]> {
    return Array.from(this.interactions.values()).filter(
      (interaction) => interaction.userId === userId
    );
  }

  async getInteractionsByProductId(productId: string): Promise<UserInteraction[]> {
    return Array.from(this.interactions.values()).filter(
      (interaction) => interaction.productId === productId
    );
  }

  async createInteraction(insertInteraction: InsertUserInteraction): Promise<UserInteraction> {
    const id = randomUUID();
    const interaction: UserInteraction = { 
      ...insertInteraction, 
      id,
      timestamp: new Date()
    };
    this.interactions.set(id, interaction);
    return interaction;
  }

  // Recommendations
  async getRecommendationsByUserId(userId: string): Promise<Recommendation[]> {
    return Array.from(this.recommendations.values()).filter(
      (rec) => rec.userId === userId
    );
  }

  async createRecommendation(insertRecommendation: InsertRecommendation): Promise<Recommendation> {
    const id = randomUUID();
    const recommendation: Recommendation = { 
      ...insertRecommendation, 
      id,
      timestamp: new Date()
    };
    this.recommendations.set(id, recommendation);
    return recommendation;
  }

  async deleteRecommendationsByUserId(userId: string): Promise<void> {
    const toDelete = Array.from(this.recommendations.entries())
      .filter(([_, rec]) => rec.userId === userId)
      .map(([id]) => id);
    
    toDelete.forEach(id => this.recommendations.delete(id));
  }
}

export const storage = new MemStorage();
